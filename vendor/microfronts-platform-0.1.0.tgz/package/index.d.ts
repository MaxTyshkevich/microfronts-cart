export interface Product { id: string; title: string; priceMinor: number; currency: string; badge?: string }
export interface CartItem { productId: string; title: string; priceMinor: number; quantity: number }
export interface Cart { items: CartItem[]; totalMinor: number; currency: string; revision: number }
export interface Platform {
  contractVersion: 1;
  apiBaseUrl: string;
  request<T>(path: string, options?: RequestInit): Promise<T>;
  events: { cartChanged(): void; onCartChanged(listener: () => void): () => void };
}
export interface RemoteProps { platform: Platform }
export function createPlatform(options?: { apiBaseUrl?: string }): Platform;
export function formatMoney(minor: number, currency?: string): string;
