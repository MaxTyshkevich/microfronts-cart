/** Each host owns its platform instance. No global bus or React dependency. */
export function createPlatform({ apiBaseUrl = '/api' } = {}) {
  const listeners = new Set();
  let memoryKey;
  function cartKey() {
    if (memoryKey) return memoryKey;
    try { memoryKey = localStorage.getItem('microfronts.demo-cart.v1'); } catch { /* storage unavailable */ }
    if (!memoryKey || !/^[0-9a-f-]{36}$/i.test(memoryKey)) memoryKey = crypto.randomUUID();
    try { localStorage.setItem('microfronts.demo-cart.v1', memoryKey); } catch { /* session-only fallback */ }
    return memoryKey;
  }
  return {
    contractVersion: 1,
    apiBaseUrl,
    async request(path, options = {}) {
      const controller = new AbortController();
      const abort = () => controller.abort();
      options.signal?.addEventListener('abort', abort, { once: true });
      if (options.signal?.aborted) abort();
      const timer = setTimeout(abort, 90000); // Free API hosting may have a cold start.
      try {
        const response = await fetch(`${apiBaseUrl.replace(/\/$/, '')}${path}`, {
          ...options,
          signal: controller.signal,
          headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers, 'X-Cart-Key': cartKey() },
        });
        if (!response.ok) {
          const body = await response.json().catch(() => null);
          throw new Error(typeof body?.message === 'string' ? body.message : `API: HTTP ${response.status}`);
        }
        return await response.json();
      } finally {
        clearTimeout(timer);
        options.signal?.removeEventListener('abort', abort);
      }
    },
    events: {
      cartChanged() { for (const listener of listeners) listener(); },
      onCartChanged(listener) { listeners.add(listener); return () => { listeners.delete(listener); }; },
    },
  };
}

export function formatMoney(minor, currency = 'USD') {
  return new Intl.NumberFormat('ru-RU', { style: 'currency', currency }).format(minor / 100);
}
